package com.ego.receive;

import com.ego.commons.exception.DaoException;
import com.ego.commons.pojo.*;
import com.ego.commons.utils.HttpClientUtil;
import com.ego.commons.utils.IDUtils;
import com.ego.commons.utils.JsonUtils;
import com.ego.dubbo.service.TbContentDubboService;
import com.ego.dubbo.service.TbItemDubboService;
import com.ego.dubbo.service.TbOrderDubboService;
import com.ego.mail.MyMailSender;
import com.ego.pojo.*;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.io.*;
import java.util.*;

/**
 * Wang PeiZhou
 * Date: 2020-05-25
 */
@Component
public class QueueListener {
    @Reference
    private TbContentDubboService tbContentDubboService;
    @Reference
    private TbItemDubboService tbItemDubboService;
    @Reference
    private TbOrderDubboService tbOrderDubboService;
    @Value("${ego.bigad.categoryId}")
    private Long bigadId;
    @Autowired
    private RedisTemplate<String,Object> redisTemplate;
    @Value("${ego.search.insert}")
    private String searchInsertUrl;
    @Value("${ego.search.delete}")
    private String searchDeleteUrl;
    @Value("${ego.cart.deletecarturl}")
    private String cartDeleteUrl;
    @Autowired
    private MyMailSender mailSender;

    // 这里也要保证本项目启动时队列没有创建的话，要自己创建队列，用到@QueueBinding注解。（注意：这是架构设计的要点，rabbitmq的发送方和接收方都要在没有队列的时候能创建队列出来）
    // 注意：只写@RabbitListener(queues = "content")是不能在没有队列的时候能创建队列出来
    @RabbitListener(bindings = {@QueueBinding(value=@Queue(name="content"),exchange=@Exchange(name = "amq.direct"))})
    public void content(Object obj){
        /*
            redis数据同步(注意：这里实现的插入删除更新业务后我们不是得同样去redis进行同样的操作，而是只做一个覆盖更新（即恒更新）的操作来完成)
            1. 从mysql中取出大广告的数据（做成Dubbo的Consumer）
            2. 把数据缓存到redis中。
         */
        // 实现方案1:把portal的consumer代码复制过来（这种方法效率更高）
        List<TbContent> list = tbContentDubboService.selectAllByCategoryid(bigadId);
        List<BigAd> listBigad = new ArrayList<>();
        for(TbContent tbContent: list){
            BigAd bigAd = new BigAd();
            bigAd.setAlt("");
            bigAd.setHeight(240);
            bigAd.setHeightB(240);
            bigAd.setHref(tbContent.getUrl());
            bigAd.setSrc(tbContent.getPic());
            bigAd.setSrcB(tbContent.getPic2());
            bigAd.setWidth(670);
            bigAd.setWidthB(550);
            listBigad.add(bigAd);
        }
        redisTemplate.opsForValue().set("com.ego.portal::bigad", JsonUtils.objectToJson(listBigad));
        // 第二种方式:直接调用ego_port
//         HttpClientUtil.doGet("http://localhost:8082/bigad");
    }

    @RabbitListener(bindings = {@QueueBinding(value = @Queue(name = "${ego.rabbitmq.item.insertName}"), exchange = @Exchange(name = "amq.direct"))})
    public void itemInsert(String id) {
        /**
         * 在rabbitmq的consumer中实现实时solr数据的同步
         * 出于架构地考虑，solr就得直接用HttpClientUtil.doPost（），而不能像上面地redis一样直接在rabbitmq_receive中就写具体实现，
         * 因为用高内聚地架构设计思路，我们将solr地具体实现放到了ego_search项目中，这样一来，我们也只能跳转地址去ego_search项目中处理
         */
        System.out.println("获取到的id:" + id);
        Map<String, String> param = new HashMap<>();
        param.put("id", id + "");
        String result = HttpClientUtil.doPost(searchInsertUrl, param);
        System.out.println("返回的结果："+result);

        /**
         * 在rabbitmq的consumer中实现实时redis缓存数据同步
         * 以后都是用这中方式编写，因为:这种方式对ego_item 能很好地保障ego_item地性能。
         * 实时redis缓存数据同步我们在后台新增修改上架商品后前台也都能直接走缓存了，太强大了
         */
        String[] ids = id.split(",");
        for(String idArr:ids){
            String key = "com.ego.item::details:" + idArr;
            TbItem tbItem = tbItemDubboService.selectById(Long.parseLong(idArr));
            TbItemDetails details = new TbItemDetails();
            details.setId(tbItem.getId());
            details.setPrice(tbItem.getPrice());
            details.setSellPoint(tbItem.getSellPoint());
            details.setTitle(tbItem.getTitle());
            String img = tbItem.getImage();
            details.setImages(img!=null&&!img.equals("")?img.split(","):new String[1]);
            redisTemplate.opsForValue().set(key,details);
        }
    }

    @RabbitListener(bindings = {@QueueBinding(value = @Queue(name = "${ego.rabbitmq.item.deleteName}"), exchange = @Exchange(name = "amq.direct"))})
    public void itemDelete(String id) {
        System.out.println("delete获取到的id:" + id);

        /**
         * 同步solr
         */
        Map<String, String> param = new HashMap<>();
        param.put("id", id + "");
        String result = HttpClientUtil.doPost(searchDeleteUrl, param);
        System.out.println("返回的结果："+result);

        /**
         * 同步redis
         */
        String[] ids = id.split(",");
        for(String idArr : ids){
            String key = "com.ego.item::details:" + idArr;
            redisTemplate.delete(key);
        }
    }

    /**
     * 创建订单队列
     * 注意：当接收消息带有返回值时，表示需要返回给发送方一个状态。发送方必须使用可接收状态的方法
     * @param msg
     */
    @RabbitListener(bindings = {@QueueBinding(value = @Queue(name = "${ego.rabbitmq.order.createorder}"), exchange = @Exchange(name = "amq.direct"))})
    public String orderCreate(Message msg) { //注意：如果传过来的消息是对象类型，则应该用参数Message,需要导入的包是org.springframework.amqp.core.Message;
        try {
            System.out.println("到receive了");
            //将传来的对象读取出来，即进行反序列化
            byte[] body = msg.getBody();
            InputStream is = new ByteArrayInputStream(body);
            ObjectInputStream objectInputStream = new ObjectInputStream(is);
            OrderPojo orderPojo = (OrderPojo)objectInputStream.readObject();

            List<TbOrderItem> listItem = orderPojo.getOrderItems();
            for(TbOrderItem tbOrderItem:listItem){
                TbItem tbItem = tbItemDubboService.selectById(Long.parseLong(tbOrderItem.getItemId()));
                if(tbItem.getNum() < tbOrderItem.getNum()){
                    return null;
                }
            }

            //如果执行到这里说明库存足够，可以调用插入数据的操作，这个插入设计到三表插入
            //准备TbOrder
            TbOrder tbOrder = new TbOrder();
            tbOrder.setPayment(orderPojo.getPayment());
            tbOrder.setPaymentType(orderPojo.getPaymentType());
            String id = "" + IDUtils.genItemId();
            tbOrder.setOrderId(id);
            Date date = new Date();
            tbOrder.setCreateTime(date);
            tbOrder.setUpdateTime(date);
            //准备List<TbOrderItem>,这里不能直接用前面的listItem，因为里面还少了东西,得循环遍历分别添加到完整信息才能往里面放
            for(TbOrderItem tbOrderItem:listItem){
                tbOrderItem.setId(IDUtils.genItemId()+"");
                tbOrderItem.setOrderId(id);//这个OrderId得用前面的，保持统一
            }
            //准备TbOrderShipping
            TbOrderShipping orderShipping = orderPojo.getOrderShipping();
            orderShipping.setOrderId(id);//这个OrderId得用前面的，保持统一
            orderShipping.setCreated(date);
            orderShipping.setUpdated(date);

            int index = tbOrderDubboService.insert(tbOrder, listItem, orderShipping);
            if (index == 1) {
                return id;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }catch (DaoException e){
            e.printStackTrace();
        }
        return null;
    }

    /**
     *
     * 注意：所以要异步处理的操作都没有返回值
     * @param msg
     */
    @RabbitListener(bindings = {@QueueBinding(value = @Queue(name = "${ego.rabbitmq.order.deletecart}"), exchange = @Exchange(name = "amq.direct"))})
    public void deleteCart(Message msg) { //注意：如果传过来的消息是对象类型，则应该用参数Message,需要导入的包是org.springframework.amqp.core.Message;
        try {
            //将传来的对象读取出来，即进行反序列化
            byte[] body = msg.getBody();
            InputStream is = new ByteArrayInputStream(body);
            ObjectInputStream objectInputStream = new ObjectInputStream(is);
            DeleteCartPojo deleteCartPojo = (DeleteCartPojo) objectInputStream.readObject();

            Map<String,String> param = new HashMap<>();
            param.put("userId",deleteCartPojo.getUserId()+"");
            param.put("itemId",deleteCartPojo.getItemIds());
            HttpClientUtil.doPost(cartDeleteUrl,param);

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @RabbitListener(bindings = {@QueueBinding(value = @Queue(name = "${ego.rabbitmq.mail}"), exchange = @Exchange(name = "amq.direct"))})
    //参数方面：这里也可以直接用Long，String等类型的参数的，内部能自动转换
    public void Mail(Message msg) {
        try {
            byte[] body = msg.getBody();
            InputStream is = new ByteArrayInputStream(body);
            ObjectInputStream objectInputStream = new ObjectInputStream(is);
            RabbitmqMailPojo rabbitmqMailPojo = (RabbitmqMailPojo) objectInputStream.readObject();
            mailSender.send(rabbitmqMailPojo.getEmail(),rabbitmqMailPojo.getOrderId());
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


}
