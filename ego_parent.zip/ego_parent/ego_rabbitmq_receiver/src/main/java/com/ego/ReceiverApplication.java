package com.ego;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Wang PeiZhou
 * Date: 2020-05-25
 */
@SpringBootApplication
public class ReceiverApplication {
    public static void main(String[] args){
        SpringApplication.run(ReceiverApplication.class,args);
    }
}
