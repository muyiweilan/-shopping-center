package com.ego.search.controller;

import com.ego.search.service.SearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class SearchController {
    @Autowired
    private SearchService searchService;

    @RequestMapping("/search.html")
    public String showSearch(String q, Model model,@RequestParam(defaultValue = "1") int page,@RequestParam(defaultValue = "12") int size){
        model.addAllAttributes(searchService.search(q,page,size));
        return "search";
    }

    /**
     * 新增
     * 这里参数long[]  id可以接受一个String，因为框架会帮我们自动按逗号隔开拆分成long类型的数组
     * @param id
     * @return
     */
    @RequestMapping("/insert")
    @ResponseBody
    public int insert(long []  id){
        return searchService.insert(id);
    }

    /**
     * 删除
     * 这里参数long[]  id可以接受一个String，因为框架会帮我们自动按逗号隔开拆分成String类型的数组
     * 这就是SpringMVC强大之处的一处体现，可以将接收到的数据转化为参数类型规定的数据类型
     * @param id
     * @return
     */
    @RequestMapping("/delete")
    @ResponseBody
    public int delete(String [] id){
        return searchService.delete(id);
    }
}
