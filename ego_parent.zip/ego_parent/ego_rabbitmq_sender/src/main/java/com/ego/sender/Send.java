package com.ego.sender;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Wang PeiZhou
 * Date: 2020-05-25
 */

/**
 * 必须确保当前类能被依赖的项目中启动类扫描到（启动类能扫描到当下所在的包中的所有包和类以及这些包下的内容包的所有包）,这个类能被其他启动类扫描到
 */
@Component
public class Send {
    @Autowired
    private AmqpTemplate amqpTemplate;

    public void send(String queue,Object obj){
        amqpTemplate.convertAndSend("amq.direct",queue,obj);
    }

    /**
     * 此方法的返回值就是receive方法的返回值
     * @param queue
     * @param obj
     * @return
     */
    public Object sendAndReceive(String queue,Object obj){
        return amqpTemplate.convertSendAndReceive("amq.direct",queue,obj);
    }
}
