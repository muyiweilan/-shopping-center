package com.ego.sender.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Wang PeiZhou
 * Date: 2020-05-25
 */

/**
 * 其实rabbitmq的队列可以在producer端用@listener注解创建，也可以在sender端用配置类创建，但是正常的处理逻辑应该两个地方都要配置
 */
@Configuration
public class SenderConfig {
    //软编码获取内容队列名称
    @Value("${ego.rabbitmq.content.queueName}")
    private String contentQueue;
    @Value("${ego.rabbitmq.item.insertName}")
    private String itemInsert;
    @Value("${ego.rabbitmq.item.deleteName}")
    private String itemDelete;
    @Value("${ego.rabbitmq.order.createorder}")
    private String createOrder;
    @Value("${ego.rabbitmq.order.deletecart}")
    private String deleteCart;
    @Value("${ego.rabbitmq.mail}")
    private String mail;

    @Bean
    public DirectExchange directExchange() {
        return new DirectExchange("amq.direct");
    }

    /**
     * 注意：这个配置的作用是在没有队列的时候创建队列！！！
     * @return
     */
    @Bean
    public Queue queue() {
        return new Queue(contentQueue);
    }
    @Bean
    // 参数名和方法名一直就是从spring容器中获取对应方法的返回值
    public Binding binding(Queue queue,DirectExchange directExchange){
        return BindingBuilder.bind(queue).to(directExchange).withQueueName();
    }

    /*
    写下面两个方法的目的：
    第一次发送消息时，如果没有队列创建队列，并绑定到amq.direct交换器上
     */
    @Bean
    public Queue queueItemInsert() {
        return new Queue(itemInsert);
    }
    @Bean
    public Binding binding2(Queue queueItemInsert, DirectExchange directExchange) {
        return BindingBuilder.bind(queueItemInsert).to(directExchange).withQueueName();
    }

    @Bean
    public Queue queueItemDelete() {
        return new Queue(itemDelete);
    }
    @Bean
    public Binding binding3(Queue queueItemDelete, DirectExchange directExchange) {
        return BindingBuilder.bind(queueItemDelete).to(directExchange).withQueueName();
    }

    /**
     * 订单队列
     */
    @Bean
    public Queue queueCreateOrder() {
        return new Queue(createOrder);
    }
    @Bean
    public Binding binding4(Queue queueCreateOrder, DirectExchange directExchange) {
        return BindingBuilder.bind(queueCreateOrder).to(directExchange).withQueueName();
    }

    /**
     * 删除购物车商品队列
     */
    @Bean
    public Queue queueDeleteCart() {
        return new Queue(deleteCart);
    }
    @Bean
    public Binding binding5(Queue queueDeleteCart, DirectExchange directExchange) {
        return BindingBuilder.bind(queueDeleteCart).to(directExchange).withQueueName();
    }

    /**
     * 发送邮件的队列
     * @return
     */
    @Bean
    public Queue queueMail() {
        return new Queue(mail);
    }
    @Bean
    public Binding binding6(Queue queueMail, DirectExchange directExchange) {
        return BindingBuilder.bind(queueMail).to(directExchange).withQueueName();
    }

}
