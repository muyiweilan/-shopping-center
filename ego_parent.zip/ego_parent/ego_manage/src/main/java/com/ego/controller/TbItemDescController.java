package com.ego.controller;

import com.ego.commons.pojo.EgoResult;
import com.ego.service.TbItemDescService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author wangpeizhou
 * @create 2020-05-13 16:54
 */
@Controller
public class TbItemDescController {
    @Autowired
    private TbItemDescService tbItemDescService;

    /**
     * 显示规格参数
     * 这个控制器接收的url是Restful风格的，传来数据包含url中，所以我们要取出其中的id，方法的对应参数要加上@PathVariable注解
     * @param id
     * @return
     */
    @RequestMapping("/rest/item/query/item/desc/{id}")
    @ResponseBody
    public EgoResult showDesc(@PathVariable Long id){
        return tbItemDescService.selectById(id);

    }
}
