package com.ego.service;

import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

/**
 * @author wangpeizhou
 * @create 2020-05-13 0:06
 */
public interface PicService {
    /**
     * 文件上传
     * @param file  SpringMVC上传文件的对象
     * @return
     */
    Map<String,Object> update(MultipartFile file);
}
