package com.ego.service;

/**
 * @author wangpeizhou
 * @create 2020-05-11 14:07
 */

/**
 * 这里的service和dubbo.service不一样，
 * 这里的service是视图逻辑，要考虑以下两个方面
 * 页面要什么？   页面要的就是方法的返回值
 * 页面能传过来什么？   传过来方法的参数
 */
public interface ManagerService {
}
