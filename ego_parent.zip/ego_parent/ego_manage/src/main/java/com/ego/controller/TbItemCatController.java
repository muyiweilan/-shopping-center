package com.ego.controller;

import com.ego.commons.pojo.EasyUITree;
import com.ego.service.TbItemCatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * @author wangpeizhou
 * @create 2020-05-13 13:56
 */
@Controller
public class TbItemCatController {
    @Autowired
    private TbItemCatService tbItemCatService;

    /**
     *
     * @param id id是EasyUI底层的参数名，固定的就叫id。表示父id
     * @return
     * 注意：@RequestParam(defaultValue = "0")是说前端页面没有传来这个参数的值时默认值为零，用于页面第一次请求时
     */
    @RequestMapping("/item/cat/list")
    @ResponseBody
    public List<EasyUITree> showTree(@RequestParam(defaultValue = "0") Long id){
        return tbItemCatService.showTree(id);
    }

}
