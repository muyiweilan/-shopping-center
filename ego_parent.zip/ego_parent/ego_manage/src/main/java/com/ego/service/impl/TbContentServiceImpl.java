package com.ego.service.impl;

import com.ego.commons.exception.DaoException;
import com.ego.commons.pojo.EasyUIDatagrid;
import com.ego.commons.pojo.EgoResult;
import com.ego.commons.utils.IDUtils;
import com.ego.dubbo.service.TbContentDubboService;
import com.ego.pojo.TbContent;
import com.ego.sender.Send;
import com.ego.service.TbContentService;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * @author wangpeizhou
 * @create 2020-05-18 1:45
 */
@Service
public class TbContentServiceImpl implements TbContentService {

    @Reference
    private TbContentDubboService tbContentDubboService;
    @Autowired
    private Send send;
    //软编码获取内容队列名称
    @Value("${ego.rabbitmq.content.queueName}")
    private String contentQueue;
    @Value("${ego.bigad.categoryId}")
    private String bigadId;
    @Override
    public EasyUIDatagrid showContent(Long categoryId, int page, int rows) {
        List<TbContent> list = tbContentDubboService.selectByPage(categoryId,page,rows);
        long total = tbContentDubboService.selectCountByCategoryId(categoryId);
        return new EasyUIDatagrid(list,total);
    }

    @Override
    public EgoResult insert(TbContent tbContent) {
        tbContent.setId(IDUtils.genItemId());
        Date date = new Date();
        tbContent.setUpdated(date);
        tbContent.setCreated(date);
        int index = tbContentDubboService.insert(tbContent);
        if (index == 1) { //说明对数据库新增成功了。
            if(tbContent.getCategoryId().toString().equals(bigadId)){
                //同步缓存，向rabbitmq发送一条消息，注意：下面这个发送到rabbitmq消息队列的代码是异步的，没有性能损耗的！！！至于耗时任务放在producer中
                send.send(contentQueue,"async");
            }
            return EgoResult.ok();
        }
        return EgoResult.error("新增失败");
    }

    @Override
    public EgoResult update(TbContent tbContent) {
        Date date = new Date();
        tbContent.setUpdated(date);
        int index = tbContentDubboService.update(tbContent);
        if (index == 1) {
            if(tbContent.getCategoryId().toString().equals(bigadId)){
                //同步缓存，向rabbitmq发送一条消息，注意：下面这个发送到rabbitmq消息队列的代码是异步的，没有性能损耗的！！！至于耗时任务放在producer中
                send.send(contentQueue,"async");
            }
            return EgoResult.ok();
        }
        return EgoResult.error("修改失败");
    }

    @Override
    public EgoResult delete(Long[] ids) {
        // 必须先查，否则删除后查询不到。
        // 因为前端页面想要删除的信息如果是大广告，那么该页面中能选择来删除的都是大广告的，所以只需要查出第一个是大广告就说明全是大广告
        boolean isBigad = tbContentDubboService.selectById(ids[0]).getCategoryId().toString().equals(bigadId)?true:false;

        try {
            int index = tbContentDubboService.delete(ids);
            if(index==1){
                if(isBigad){
                    send.send(contentQueue,"async");
                }
                return EgoResult.ok();
            }
        } catch (DaoException e) {
            e.printStackTrace();
        }
        return EgoResult.error("删除失败");
    }
}
