package com.ego.service.impl;

import com.ego.dubbo.service.ManagerDubboService;
import com.ego.pojo.Manager;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 * @author wangpeizhou
 * @create 2020-05-11 14:25
 */

/**
 * Consumer的@Service注解是Spring的
 */
@Service
public class LoginServiceImpl implements UserDetailsService {

    //注意这里是apache的注解，如果导入jdk的@Reference会出现空指针异常
    @Reference
    private ManagerDubboService managerDubboService;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Manager manager = managerDubboService.selectManagerByUsername(username);
        if (manager == null) {
            throw new UsernameNotFoundException("用户不存在");
        }
        return new User(username,manager.getPassword(), AuthorityUtils.commaSeparatedStringToAuthorityList("不涉及权限"));
    }
}
