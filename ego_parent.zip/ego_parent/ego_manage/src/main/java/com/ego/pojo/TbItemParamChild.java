package com.ego.pojo;

/**
 * @author wangpeizhou
 * @create 2020-05-17 0:16
 */
/**
 * 页面查询参数功能要展示的参数比TbItemParam实体类要多一个参数，只是我们的处理方式是创建一个新的实体类继承TbItemParam并且定义
 * 缺乏的那个属性，将这个子类作为商品参数的实体类
 */
public class TbItemParamChild extends TbItemParam {
    private String itemCatName;

    public String getItemCatName() {
        return itemCatName;
    }

    public void setItemCatName(String itemCatName) {
        this.itemCatName = itemCatName;
    }
}
