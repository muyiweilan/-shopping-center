package com.ego.service;

import com.ego.commons.pojo.EasyUIDatagrid;
import com.ego.commons.pojo.EgoResult;
import com.ego.pojo.TbContent;

/**
 * @author wangpeizhou
 * @create 2020-05-18 1:43
 */
public interface TbContentService {
    /**
     * 分页查询
     * @param categoryId
     * @param page
     * @param rows
     * @return
     */
    EasyUIDatagrid showContent(Long categoryId,int page,int rows);

    /**
     * 新增
     * @param tbContent
     * @return
     */
    EgoResult insert(TbContent tbContent);

    /**
     * 修改
     * @param tbContent
     * @return
     */
    EgoResult update(TbContent tbContent);

    /**
     * 删除
     * @param ids
     * @return
     */
    EgoResult delete(Long[] ids);
}
