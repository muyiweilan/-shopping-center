package com.ego.service;

import com.ego.commons.pojo.EasyUIDatagrid;
import com.ego.commons.pojo.EgoResult;
import com.ego.pojo.TbItemParam;

/**
 * @author wangpeizhou
 * @create 2020-05-17 0:21
 */
public interface TbItemParamService {
    EasyUIDatagrid showItemParam(int page,int rows);

    /**
     * 根据类目id查询规格参数模板
     * 注意：页面要的数据在js中可以看到，要status和data两个参数信息，所以这里要返回封装好的EgoResult对象
     * @param catId
     * @return
     */
    EgoResult showItemParamByCatId(Long catId);

    /**
     * 新增规格模板
     * @param tbItemParam
     * @return
     */
    EgoResult insert(TbItemParam tbItemParam);

    /**
     * 批量删除
     * @param ids
     * @return
     */
    EgoResult delete(Long[] ids);
}
