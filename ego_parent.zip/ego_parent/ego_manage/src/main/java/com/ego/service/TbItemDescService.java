package com.ego.service;

import com.ego.commons.pojo.EgoResult;

/**
 * @author wangpeizhou
 * @create 2020-05-13 16:48
 */
public interface TbItemDescService {
    EgoResult selectById(Long id);
}
