package com.ego.service;

import com.ego.commons.pojo.EgoResult;
import com.ego.pojo.TbItemParamItem;

/**
 * @author wangpeizhou
 * @create 2020-05-17 14:43
 */
public interface TbItemParamItemService {
    /**
     * 根据商品id查询商品规格参数
     * @param itemId
     * @return
     */
    public EgoResult showItemParamByItemId(Long itemId);
}
