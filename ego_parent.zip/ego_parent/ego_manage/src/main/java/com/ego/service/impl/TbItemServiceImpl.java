package com.ego.service.impl;

import com.ego.commons.exception.DaoException;
import com.ego.commons.pojo.EasyUIDatagrid;
import com.ego.commons.pojo.EgoResult;
import com.ego.commons.utils.IDUtils;
import com.ego.dubbo.service.TbItemDubboService;
import com.ego.pojo.TbItem;
import com.ego.pojo.TbItemDesc;
import com.ego.pojo.TbItemParamItem;
import com.ego.sender.Send;
import com.ego.service.TbItemService;
import org.apache.commons.lang3.StringUtils;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * @author wangpeizhou
 * @create 2020-05-12 14:23
 */
@Service
public class TbItemServiceImpl implements TbItemService {

    @Reference
    private TbItemDubboService tbItemDubboService;
    @Autowired
    private Send send;
    @Value("${ego.rabbitmq.item.insertName}")
    private String itemInsert;
    @Value("${ego.rabbitmq.item.deleteName}")
    private String itemDelete;

    @Override
    public EasyUIDatagrid showItem(int page, int rows) {
        List<TbItem> list = tbItemDubboService.selectByPage(rows, page);
        long total = tbItemDubboService.selectCount();
        return new EasyUIDatagrid(list,total);
    }

    @Override
    public EgoResult updateStatus(long[] ids, int status) {
        try {
            int index = tbItemDubboService.updateStatusByIds(ids, status);
            if (index == 1) {

                //上架或下架操作后让solr与数据库数据用异步的方式同步
                if(status==1){ //表示上架
                    // 对solr就是新增
                    send.send(itemInsert, StringUtils.join(ids,','));
                }else if(status==2 || status ==3){
                    send.send(itemDelete,StringUtils.join(ids,','));
                }

                return EgoResult.ok();
            }
        } catch (DaoException e) {
            e.printStackTrace();
        }
        return EgoResult.error("操作失败");
    }

    @Override
    public EgoResult insert(TbItem item, String desc,String itemParams) {
        Date date = new Date();
        //使用IDUtils工具包随机生成id。一般分布式开发项目中的实体类对象的id都要是通过一定的策略随机生成的
        long id = IDUtils.genItemId();
        //商品信息表数据
        item.setId(id);
        item.setUpdated(date);
        item.setCreated(date);
        item.setStatus((byte)1);
        //商品描述表数据
        TbItemDesc tbItemDesc = new TbItemDesc();
        tbItemDesc.setItemId(id);
        tbItemDesc.setItemDesc(desc);
        tbItemDesc.setCreated(date);
        tbItemDesc.setUpdated(date);
        //商品规格参数表数据
        TbItemParamItem tbItemParamItem = new TbItemParamItem();
        tbItemParamItem.setId(IDUtils.genItemId());
        tbItemParamItem.setCreated(date);
        tbItemParamItem.setUpdated(date);
        tbItemParamItem.setItemId(id);
        tbItemParamItem.setParamData(itemParams);

        try {
            int index = tbItemDubboService.insert(item, tbItemDesc,tbItemParamItem);
            if (index == 1) {

                //新增操作后让solr与数据库数据用异步的方式同步
                send.send(itemInsert,id);

                return EgoResult.ok();
            }
        } catch (DaoException e) {
            e.printStackTrace();
        }
        return EgoResult.error("新增失败");
    }

    @Override
    public EgoResult update(TbItem item, String desc,String itemParams,Long itemParamId) {
        Date date = new Date();
        //修改商品信息
        item.setUpdated(date);
        //修改商品描述
        TbItemDesc tbItemDesc = new TbItemDesc();
        tbItemDesc.setItemId(item.getId());
        tbItemDesc.setUpdated(date);
        tbItemDesc.setItemDesc(desc);
        //修改商品规格参数
        TbItemParamItem tbItemParamItem = new TbItemParamItem();
        tbItemParamItem.setId(itemParamId);
        tbItemParamItem.setParamData(itemParams);
        tbItemParamItem.setUpdated(date);
        try {
            int index = tbItemDubboService.update(item,tbItemDesc,tbItemParamItem);
            if(index == 1){

                //更新操作后让solr与数据库数据用异步的方式同步
                send.send(itemInsert,item.getId());

                return EgoResult.ok();
            }
        } catch (DaoException e) {
            e.printStackTrace();
        }
        return EgoResult.error("修改失败");
    }

}
