package com.ego.item.controller;

import com.ego.item.pojo.ItemCategoryNav;
import com.ego.item.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author wangpeizhou
 * @create 2020-05-20 2:35
 */
@Controller
public class ItemController {
    @Autowired
    private ItemService itemService;

    @RequestMapping("/rest/itemcat/all")
    @ResponseBody
    //一定要记得添加跨域请求的注解！！！
    @CrossOrigin
    public ItemCategoryNav showItemCat(){
        long startTime = System.currentTimeMillis();
        ItemCategoryNav itemCategoryNav = itemService.showItemCat();
        long endTime = System.currentTimeMillis();
        System.out.println(endTime-startTime);
        return itemCategoryNav;
    }

    /**
     * 显示商品详情页面
     * @param id
     * @param model
     * @return
     */
    @RequestMapping("/item/{id}.html")
    //因为查看了jsp页面，页面中要通过作用域取值即"${}"，所以我们要加一个Model参数将数据传过去
    public String showItem(@PathVariable Long id, Model model){
        model.addAttribute("item",itemService.showItem(id));
        return "item";
    }

    /**
     * 显示商品描述
     * @param id
     * @return
     */
    @RequestMapping("/item/desc/{id}.html")
    //一定不要忘了@ResponseBody注解，因为这个访问时Ajax请求，不是页面跳转
    @ResponseBody
    public String showItemDesc(@PathVariable Long id){
        return itemService.showItemDesc(id);
    }

    /**
     * 显示商品规格参数信息
     * @param id
     * @return
     */
    @RequestMapping("/item/param/{id}.html")
    @ResponseBody
    public String showParamItem(@PathVariable Long id){
        return itemService.showItemParam(id);
    }
}
