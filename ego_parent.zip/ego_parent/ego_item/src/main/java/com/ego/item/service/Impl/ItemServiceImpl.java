package com.ego.item.service.Impl;

import com.ego.commons.pojo.TbItemDetails;
import com.ego.commons.utils.JsonUtils;
import com.ego.dubbo.service.TbItemCatDubboService;
import com.ego.dubbo.service.TbItemDescDubboService;
import com.ego.dubbo.service.TbItemDubboService;
import com.ego.dubbo.service.TbItemParamItemDubboService;
import com.ego.item.pojo.CategoryNode;
import com.ego.item.pojo.ItemCategoryNav;
import com.ego.item.pojo.ParamItem;
import com.ego.item.service.ItemService;
import com.ego.pojo.TbItem;
import com.ego.pojo.TbItemCat;
import com.ego.pojo.TbItemDesc;
import com.ego.pojo.TbItemParamItem;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wangpeizhou
 * @create 2020-05-20 2:12
 */
@Service
public class ItemServiceImpl implements ItemService {

    @Reference
    private TbItemCatDubboService tbItemCatDubboService;
    @Reference
    private TbItemDubboService tbItemDubboService;
    @Reference
    private TbItemDescDubboService tbItemDescDubboService;
    @Reference
    private TbItemParamItemDubboService tbItemParamItemDubboService;

    @Override
    @Cacheable(cacheNames = "com.ego.item", key = "'showItemCat'")
    public ItemCategoryNav showItemCat() {
        ItemCategoryNav itemCategoryNav = new ItemCategoryNav();
        itemCategoryNav.setData(getAllItemCat(0l));
        return itemCategoryNav;
    }

    @Override
    @Cacheable(cacheNames = "com.ego.item", key = "'details:'+#id")
    public TbItemDetails showItem(Long id) {
        TbItem tbItem = tbItemDubboService.selectById(id);
        TbItemDetails details = new TbItemDetails();
        details.setId(tbItem.getId());
        details.setPrice(tbItem.getPrice());
        details.setSellPoint(tbItem.getSellPoint());
        details.setTitle(tbItem.getTitle());
        String img = tbItem.getImage();
        details.setImages(img != null && !img.equals("") ? img.split(",") : new String[1]);
        return details;
    }

    @Override
    public String showItemDesc(Long itemid) {
        TbItemDesc tbItemDesc = tbItemDescDubboService.selectById(itemid);
        return tbItemDesc.getItemDesc();
    }

    @Override
    public String showItemParam(Long itemId) {
        TbItemParamItem tbItemParamItem = tbItemParamItemDubboService.selectByItemId(itemId);
        String json = tbItemParamItem.getParamData();
        List<ParamItem> list = JsonUtils.jsonToList(json, ParamItem.class);
        StringBuffer sf = new StringBuffer();
        for (ParamItem paramItem : list) {
            // 把一个ParamItem当作一个表格看待
            sf.append("<table style='color:gray;' width='100%' cellpadding='5'>");
            for (int i = 0; i < paramItem.getParams().size(); i++) {
                sf.append("<tr>");
                if (i == 0) {// 说明是第一行，第一行要显示分组信息
                    sf.append("<td style='width:100px;text-align:right;'>" + paramItem.getGroup() + "</td>");
                } else {
                    // html列是空最好给个空格
                    sf.append("<td> </td>");// 除了第一行以外其他行第一列都是空。
                }
                sf.append("<td style='width:200px;text-align:right;'>" + paramItem.getParams().get(i).getK() + "</td>");
                sf.append("<td>" + paramItem.getParams().get(i).getV() + "</td>");
                sf.append("</tr>");
            }
            sf.append("</table>");
            sf.append("<hr style='color:gray;'/>");
        }
        return sf.toString();
    }

    private List<Object> getAllItemCat(Long parentId) {
        List<TbItemCat> list = tbItemCatDubboService.selectByPid(parentId);
        List<Object> listResult = new ArrayList<>();
        //一个cat对应一个菜单项目，前两层类型都是CategoryNode类型，第三层是String
        for (TbItemCat cat : list) {
            if (cat.getIsParent()) { //说明是第一层或者第二层，即有子节点的层
                CategoryNode node = new CategoryNode();
                node.setU("/products/" + cat.getId() + ".html");
                node.setN("<a href='/products/" + cat.getId() + ".html'>" + cat.getName() + "</a>");
                node.setI(getAllItemCat(cat.getId()));
                listResult.add(node);
            } else {
                listResult.add("/products/" + cat.getId() + ".html|" + cat.getName());
            }
        }
        return listResult;
    }
}
