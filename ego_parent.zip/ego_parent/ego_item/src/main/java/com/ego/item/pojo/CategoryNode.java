package com.ego.item.pojo;

import java.util.List;

/**
 * @author wangpeizhou
 * @create 2020-05-20 2:07
 */
//返回的总体数据
public class CategoryNode {
    private String n;
    private String u;
    private List<Object> i;

    public String getN() {
        return n;
    }

    public void setN(String n) {
        this.n = n;
    }

    public String getU() {
        return u;
    }

    public void setU(String u) {
        this.u = u;
    }

    public List<Object> getI() {
        return i;
    }

    public void setI(List<Object> i) {
        this.i = i;
    }
}
