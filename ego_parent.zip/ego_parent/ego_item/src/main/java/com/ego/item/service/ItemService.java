package com.ego.item.service;

import com.ego.commons.pojo.TbItemDetails;
import com.ego.item.pojo.ItemCategoryNav;

/**
 * @author wangpeizhou
 * @create 2020-05-20 2:11
 */
public interface ItemService {
    /**
     * 显示导航菜单
     * @return
     */
    ItemCategoryNav showItemCat();

    /**
     * 显示商品详情
     * @param id
     * @return
     */
    TbItemDetails showItem(Long id);

    /**
     * 显示商品描述
     * @param itemid
     * @return
     */
    String showItemDesc(Long itemid);

    /**
     * 显示商品规格参数
     * @param itemId
     * @return
     */
    String showItemParam(Long itemId);
}
