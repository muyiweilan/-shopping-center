package com.ego.item.pojo;

import java.util.List;

/**
 * @author wangpeizhou
 * @create 2020-05-20 2:04
 */
//导航菜单项
public class ItemCategoryNav {
    private List<Object> data;

    public List<Object> getData() {
        return data;
    }

    public void setData(List<Object> data) {
        this.data = data;
    }
}
