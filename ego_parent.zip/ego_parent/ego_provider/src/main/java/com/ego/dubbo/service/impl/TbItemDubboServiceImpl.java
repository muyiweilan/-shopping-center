package com.ego.dubbo.service.impl;

import com.ego.commons.exception.DaoException;
import com.ego.dubbo.service.TbItemDubboService;
import com.ego.mapper.TbItemDescMapper;
import com.ego.mapper.TbItemMapper;
import com.ego.mapper.TbItemParamItemMapper;
import com.ego.pojo.TbItem;
import com.ego.pojo.TbItemDesc;
import com.ego.pojo.TbItemParamItem;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * @author wangpeizhou
 * @create 2020-05-12 13:46
 */

/**
 * Provider要把当前类实现的接口发布到zookeeper中，默认情况下Dubbo的Provider端口为20880，Consumer会监听Provider的20880端口，
 * 要用apache的@Service注解
 */
@Service
public class TbItemDubboServiceImpl implements TbItemDubboService {

    @Autowired
    private TbItemMapper tbItemMapper;
    @Autowired
    private TbItemDescMapper tbItemDescMapper;
    @Autowired
    private TbItemParamItemMapper tbItemParamItemMapper;

    @Override
    public List<TbItem> selectByPage(int pageSize, int pageNumber) {
        // 分页插件要写在查询上面。否则插件无效。一般都写在第一行
        PageHelper.startPage(pageNumber, pageSize);
        // Example相当于sql中where,没有where时参数为null即可
        // select * from tb_item limit ?,?
        List<TbItem> list = tbItemMapper.selectByExample(null);
        // 千万不要忘记构造方法参数。
        PageInfo<TbItem> pi = new PageInfo<>(list);
        return pi.getList();
    }

    @Override
    public long selectCount() {
        return tbItemMapper.countByExample(null);
    }

    @Override
    // 监听到异常，执行事务回滚。声明式事务注解
    @Transactional
    public int updateStatusByIds(long[] ids, int status) throws DaoException {
        int index = 0 ;
        Date date = new Date();
        for(long id : ids){
            TbItem tbItem = new TbItem();
            tbItem.setId(id);
            tbItem.setStatus((byte)status);
            tbItem.setUpdated(date);
            index+=tbItemMapper.updateByPrimaryKeySelective(tbItem);
        }
        // 修改的条数和数组长度一样，说明都修改了。成功成功
        if(index==ids.length){
            return 1;
        }
        // 让事务回滚
        throw new DaoException("批量修改失败");
    }

    /**
     * 新增商品
     * 注意：这个操作要一次性操作两张表，一张商品信息表和一张商品描述表，操作一张表失败则本次操作失败，所以可以用if嵌套的方式来处理,并且给方法增添事务注解
     * @param tbItem
     * @param tbItemDesc
     * @return
     */
    /**
     * ！！特别注意：
     * --这个方法中的异常处理方面抛出的异常是自定义异常，我们让这个自定义异常继承的是受检异常Exception，这样会影响到
     *      事物处理，所以要在@Transactional注解加一个参数：rollbackFor=Exception.class，否则无法处理事务；
     * --另外一张解决方案是，让我们的自定义异常继承RuntimeException类，这样的话直接用@Transactional注解就行，什么也不用加
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int insert(TbItem tbItem, TbItemDesc tbItemDesc, TbItemParamItem tbItemParamItem) throws DaoException{
        int index = tbItemMapper.insert(tbItem);//这里id是一定有的，所有不需要用动态sql，即insertSelective（）方法
        if (index == 1) {//说明商品信息插入成功，那么接下来插入商品描述
            int index2 = tbItemDescMapper.insert(tbItemDesc);
            if (index2 == 1) {
                int index3 = tbItemParamItemMapper.insert(tbItemParamItem);
                if (index3 == 1) {
                    return 1;
                }
            }
        }
        throw new DaoException("新增失败");
    }

    /**
     * 修改
     * @param tbItem
     * @param tbItemDesc
     * @return
     * @throws DaoException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(TbItem tbItem, TbItemDesc tbItemDesc,TbItemParamItem tbItemParamItem) throws DaoException {
        //一定要调用XXXselective，即动态sql，因为创建时间这个字段我们是不能覆盖的，不能动它,策略是有的就新增，没有的就不增
        int index = tbItemMapper.updateByPrimaryKeySelective(tbItem);
        if (index == 1) {
            int index2 = tbItemDescMapper.updateByPrimaryKeySelective(tbItemDesc);
            if (index2 == 1) {
                int index3 = tbItemParamItemMapper.updateByPrimaryKeySelective(tbItemParamItem);
                if (index3 == 1) {
                    return 1;
                }
            }
        }
        throw new DaoException("修改失败");
    }

    @Override
    public TbItem selectById(Long id) {
        return tbItemMapper.selectByPrimaryKey(id);
    }

}
