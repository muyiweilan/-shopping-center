package com.ego;

import org.apache.dubbo.config.spring.context.annotation.EnableDubbo;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author wangpeizhou
 * @create 2020-05-11 0:56
 */
@SpringBootApplication
@EnableDubbo
//因为mapper包中的类都没有加注解，所以在启动类要加@MapperScan("com.ego.mapper")注解来解析mapper包中的类
@MapperScan("com.ego.mapper")
public class ProviderApplication {
    public static void main(String[] args) {
        SpringApplication.run(ProviderApplication.class,args);
    }
}
