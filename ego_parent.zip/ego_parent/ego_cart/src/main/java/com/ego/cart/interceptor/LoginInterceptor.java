package com.ego.cart.interceptor;

import com.ego.pojo.TbUser;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 查看HandlerInterceptor 接口的源码，可以看到高版本的spring-webmvc jar包中，HandlerInterceptor 接口定义的是默认方法，
 * 方法前面有“default”修饰，这是jdk1.8的新特性，也就是说接口中的方法你重写也可以，不重写也不会报错，idea也不会提醒你重写。
 */
//要对这个类加上@Component注解，将其放到Spring容器中，以便配置类InteceptorConfig可以对其进行注册
@Component
public class LoginInterceptor implements HandlerInterceptor {
    @Value("${ego.passport.loginurl}")
    private String loginUrl;

    /**
     * 在控制器方法之前执行用preHandle方法
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        TbUser tbUser = (TbUser) request.getSession().getAttribute("loginUser");
        //如果用户登陆了
        if(tbUser!=null){
            System.out.println("已经登录");
            return true;
        }
        //如果用户没登陆，则重定向到登录页面
        response.sendRedirect(loginUrl);
        return false;
    }
}
