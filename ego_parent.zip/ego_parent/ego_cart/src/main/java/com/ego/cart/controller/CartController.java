package com.ego.cart.controller;

import com.ego.cart.service.CartService;
import com.ego.commons.pojo.EgoResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class CartController {
    @Autowired
    private CartService cartService;

    /**
     * 加入购物车
     * @param id
     * @param num
     * @return
     */
    @RequestMapping("/cart/add/{id}.html")
    public String addCart(@PathVariable Long id,int num){
        cartService.addCart(id,num);
        return "cartSuccess";
    }

    /**
     * 显示购物车数据
     * @param model
     * @return
     */
    @RequestMapping("/cart/cart.html")
    public String showCart(Model model){
        model.addAttribute("cartList",cartService.showCart());
        return "cart";
    }

    /**
     * 修改购物车中商品数量
     * 由于前台页面中购物车商品数量递增和数量输入的发送的url不一样，但实现的逻辑是一样的，所以我们可以在@RequestMapping的参数中
     * 用value={"...","..."}的方式来写，这叫多url映射，SpringMVC也是支持这种功能的
     * @param id
     * @param num
     * @return
     */
    @RequestMapping(value={"/cart/update/num/{id}/{num}.action","/service/cart/update/num/{id}/{num}"})
    @ResponseBody
    public EgoResult updateNum(@PathVariable Long id, @PathVariable int num){
        return cartService.updateNum(id,num);
    }

    /**
     * 删除购物车数据
     * @param id
     * @return
     */
    @RequestMapping("/cart/delete/{id}.action")
    @ResponseBody
    public EgoResult delete(@PathVariable Long id){
        return cartService.delele(id);
    }


    /**
     * 显示结算页面
     * 这个方法中，页面传来了多个同名参数，在SpringMVC中是支持这种功能的，我们可以用一个List去接收这些同名参数
     * 注意：这里有个业务逻辑：如果用户未登录要请求结算，得让页面跳转到登陆页面；如果不是可以直接跳转到结算页面
     *      对于判断是否登录这个逻辑在很多servlet都会用到，为了避免代码冗余，我们可以用拦截器实现的实现
     *      （showOrderCart()方法在SpringMVC中被叫做HandleMethod，即控制器方法，拦截器可以在这个方法之前拦截信息）
     * @return
     */
    @RequestMapping("/cart/order-cart.html")
    public String showOrderCart(@RequestParam("id") List<Long> id,Model model){
        model.addAttribute("cartList",cartService.showOrderCart(id));
        System.out.println(id);
        return "order-cart";
    }

    /**
     * 注意：这个控制器不是给页面传来的url用的，而是设计给删除redis缓存中商品数据用的，这里的Long[]类型的参数不能写为List<Long>类型，否则SpringMVC无法接收并解析
     */
    @RequestMapping("/cart/deleteByIds")
    @ResponseBody
    public int deleteUsercartByItemsIds(Long userId,Long[] itemId){
        return cartService.deleteUserCartByItemId(userId,itemId);
    }
}
