package com.ego.cart.service;

import com.ego.cart.pojo.OrderCartPojo;
import com.ego.commons.pojo.CartPojo;
import com.ego.commons.pojo.EgoResult;

import java.util.List;

public interface CartService {
    /**
     * 添加购物车
     * @param id
     * @param num
     */
    void addCart(Long id, int num);

    /**
     * 显示购物车数据
     * @return
     */
    List<CartPojo> showCart();

    /**
     * 修改购物车中商品数量
     * @param id
     * @param num
     * @return
     */
    EgoResult updateNum(Long id, int num);

    /**
     * 根据id删除购物车数据
     * @param id
     * @return
     */
    EgoResult delele(Long id);

    /**
     * 显示结算页面
     * @param ids
     * @return
     */
    List<OrderCartPojo> showOrderCart(List<Long> ids);

    /**
     * 根据商品id删除指定用户购物车商品
     * @param userId
     * @param ids
     * @return
     */
    int deleteUserCartByItemId(Long userId,Long[] ids);
}
