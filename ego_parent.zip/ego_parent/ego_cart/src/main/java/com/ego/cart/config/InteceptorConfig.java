package com.ego.cart.config;

import com.ego.cart.interceptor.LoginInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class InteceptorConfig implements WebMvcConfigurer {
    @Autowired
    private LoginInterceptor loginInterceptor;
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        //配置类中需要将写好的拦截器实现类进行注册，然后添加拦截路径
        registry.addInterceptor(loginInterceptor).addPathPatterns("/cart/order-cart.html");
    }
}
