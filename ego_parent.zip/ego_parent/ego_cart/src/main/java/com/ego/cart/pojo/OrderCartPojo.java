package com.ego.cart.pojo;

import com.ego.commons.pojo.CartPojo;

public class OrderCartPojo extends CartPojo {
    private Boolean enough;

    public Boolean getEnough() {
        return enough;
    }

    public void setEnough(Boolean enough) {
        this.enough = enough;
    }
}
