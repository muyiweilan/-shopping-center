package com.ego.commons.pojo;

import java.io.Serializable;

/**
 * Wang PeiZhou
 * Date: 2020-06-05
 */
public class DeleteCartPojo implements Serializable {
    public static final long serialVersionUID = 1L;
    private Long userId;
    private String itemIds;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getItemIds() {
        return itemIds;
    }

    public void setItemIds(String itemIds) {
        this.itemIds = itemIds;
    }
}
