package com.ego.commons.exception;

/**
 * @author wangpeizhou
 * @create 2020-05-12 16:56
 */
public class DaoException extends RuntimeException {
    public DaoException(String message) {
        super(message);
    }
}
