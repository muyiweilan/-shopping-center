package com.ego.commons.pojo;

/**
 * @author wangpeizhou
 * @create 2020-05-12 14:14
 */

import java.util.List;

/**
 * EasyUI datagrid 数据模板
 * 由于我们前端页面使用了EasyUI模板，在传输数据的时候会有很多相同的操作，所以我们可以抽象出一个模板commons
 */
public class EasyUIDatagrid {
    private List<?> rows;
    private long total;

    public EasyUIDatagrid() {
    }

    public EasyUIDatagrid(List<?> rows, long total) {
        this.rows = rows;
        this.total = total;
    }

    public long getTotal() {
        return total;
    }

    public void setTotal(long total) {
        this.total = total;
    }

    public List<?> getRows() {
        return rows;
    }

    public void setRows(List<?> rows) {
        this.rows = rows;
    }
}
