package com.ego.commons.pojo;

import java.io.Serializable;

/**
 * Wang PeiZhou
 * Date: 2020-06-06
 */
public class RabbitmqMailPojo implements Serializable {
    public static final long serialVersionUID=1L;
    private String email;
    private String orderId;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}
