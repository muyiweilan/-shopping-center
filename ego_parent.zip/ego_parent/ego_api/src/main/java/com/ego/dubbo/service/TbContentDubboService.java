package com.ego.dubbo.service;

import com.ego.commons.exception.DaoException;
import com.ego.pojo.TbContent;

import java.util.List;

/**
 * @author wangpeizhou
 * @create 2020-05-18 1:24
 */
public interface TbContentDubboService {
    /**
     * 不同分类下的模糊查询
     * @param categoryId
     * @param pageNumber
     * @param pageSize
     * @return
     */
    List<TbContent> selectByPage(Long categoryId,int pageNumber,int pageSize);

    /**
     * 根据类目id查询该类目数量
     * @param categoryId
     * @return
     */
    long selectCountByCategoryId(Long categoryId);

    /**
     * 新增
     * @param tbContent
     * @return
     */
    int insert(TbContent tbContent);

    /**
     * 修改
     * @param tbContent
     * @return
     */
    int update(TbContent tbContent);

    /**
     * 删除
     * @param ids
     * @return
     */
    int delete(Long[] ids) throws DaoException;

    /**
     * 查询全部。按照更新时间降序排序
     * @param categoryId
     * @return
     */
    List<TbContent> selectAllByCategoryid(Long categoryId);

    /**
     * 根据主键查询
     * @param id 主键
     * @return 详细信息
     */
    TbContent selectById(Long id);
}
