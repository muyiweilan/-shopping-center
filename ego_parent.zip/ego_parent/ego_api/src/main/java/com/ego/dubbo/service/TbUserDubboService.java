package com.ego.dubbo.service;

import com.ego.pojo.TbUser;

/**
 * Wang PeiZhou
 * Date: 2020-06-01
 */
public interface TbUserDubboService {
    /**
     * 根据用户信息查询用户（这里使用动态SQL完成）（用于信息校验）
     * @param user
     * @return
     */
    TbUser selectByUser(TbUser user);

    /**
     * 新增（用于注册添加用户）
     * @param tbUser
     * @return
     */
    int insert(TbUser tbUser);

    /**
     * 更具用户名和密码查询用户（用于登录）
     * @param tbUser
     * @return
     */
    TbUser selectByUsernamePwd(TbUser tbUser);
}
