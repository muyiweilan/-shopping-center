package com.ego.dubbo.service;

import com.ego.pojo.TbItemDesc;

/**
 * @author wangpeizhou
 * @create 2020-05-13 16:42
 */
public interface TbItemDescDubboService {
    /**
     * 根据主键查询信息
     * @param id
     * @return
     */
    TbItemDesc selectById(Long id);
}
