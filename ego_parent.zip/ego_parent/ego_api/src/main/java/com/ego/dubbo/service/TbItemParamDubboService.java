package com.ego.dubbo.service;

import com.ego.commons.exception.DaoException;
import com.ego.commons.pojo.EgoResult;
import com.ego.pojo.TbItemParam;

import java.util.List;

/**
 * @author wangpeizhou
 * @create 2020-05-16 23:50
 */

public interface TbItemParamDubboService {
    /**
     * 分页查询
     * @param pageNumber
     * @param pageSize
     * @return
     */
    List<TbItemParam> selectByPage(int pageNumber,int pageSize);

    /**
     * 查询总数量
     * @return
     */
    long selectCount();

    /**
     * 根据商品类目查询商品规格参数模板信息
     * @param catId
     * @return
     */
    TbItemParam selectByCatId(Long catId);

    /**
     * 新增规格模板
     * @param tbItemParam
     * @return
     */
    int insert(TbItemParam tbItemParam);

    /**
     * 批量删除
     * @param ids
     * @return
     */
    int delete(Long[] ids) throws DaoException;
}
