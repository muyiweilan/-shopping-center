package com.ego.dubbo.service;

import com.ego.pojo.TbItemCat;

import java.util.List;

/**
 * @author wangpeizhou
 * @create 2020-05-13 13:18
 */
public interface TbItemCatDubboService {

    //提示：写provider接口的时候要考虑目的是从数据库要什么

    /**
     * 根据父id查询所有子类目
     * @param pid 父id
     * @return 所有子类目
     */
    List<TbItemCat> selectByPid(Long pid);

    /**
     * 根据主键查询类目
     * @param id 主键
     * @return 详细数据
     */
    TbItemCat selectByid(Long id);


}
