package com.ego.dubbo.service;

import com.ego.pojo.Manager;

/**
 * @author wangpeizhou
 * @create 2020-05-11 13:28
 */
public interface ManagerDubboService {
    /**
     * 根据用户查询后台用户信息
     * @param username 用户名
     * @return 用户详情
     */
    Manager selectManagerByUsername(String username);
}
