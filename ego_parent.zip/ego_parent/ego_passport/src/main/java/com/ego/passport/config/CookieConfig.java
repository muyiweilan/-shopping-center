package com.ego.passport.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.session.web.http.CookieHttpSessionIdResolver;
import org.springframework.session.web.http.CookieSerializer;
import org.springframework.session.web.http.DefaultCookieSerializer;
import org.springframework.session.web.http.HttpSessionIdResolver;

/**
 * 修改SpringSession中Cookie数据地配置类，这里用于修改cookie名字
 */
@Configuration
public class CookieConfig {

    @Bean
    public CookieSerializer cookieSerializer(){
        DefaultCookieSerializer cookie = new DefaultCookieSerializer();
        //设置CookieName
        cookie.setCookieName("TT_TOKEN");
        //设置cookie是否能被客户端脚本如js读取，为true时不能获取，为false时可以获取
        cookie.setUseHttpOnlyCookie(false);
        return cookie;
    }

    @Bean
    public HttpSessionIdResolver httpSessionIdResolver(){
        CookieHttpSessionIdResolver resolver = new CookieHttpSessionIdResolver();
        //设置Cookie序列化器，这里调用了上面的cookieSerializer()方法
        resolver.setCookieSerializer(cookieSerializer());
        return resolver;
    }
}
