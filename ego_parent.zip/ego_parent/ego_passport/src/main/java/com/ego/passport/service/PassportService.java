package com.ego.passport.service;

import com.ego.commons.pojo.EgoResult;
import com.ego.pojo.TbUser;

/**
 * Wang PeiZhou
 * Date: 2020-06-01
 */
public interface PassportService {
    /**
     * 检擦用户是否存在
     * @param tbUser
     * @return
     */
    EgoResult check(TbUser tbUser);

    /**
     * 注册
     * @param tbUser
     * @return
     */
    EgoResult register(TbUser tbUser);

    /**
     * 登录
     * @param tbUser
     * @return
     */
    EgoResult login(TbUser tbUser);

}
