package com.ego.passport.controller;

import com.ego.commons.pojo.EgoResult;
import com.ego.passport.service.PassportService;
import com.ego.pojo.TbUser;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;

/**
 * Wang PeiZhou
 * Date: 2020-06-01
 */
@Controller
public class PassportController {
    @Autowired
    private PassportService passportService;

    /**
     * 显示登录页面
	 * 注意：得处理一个业务逻辑：登陆成功后跳转到原来的页面，但注册成功后要跳转到首页
     * @param referer
     * @param model
     * @return
     */
    @RequestMapping("/user/showLogin")
    public String showLogin(@RequestHeader(name = "Referer",required = false) String referer, Model model){
        if(Strings.isNotEmpty(referer)){
            if(!referer.endsWith("/user/showRegister")){
                model.addAttribute("redirect",referer);
            }
        }
        return "login";
    }

    /**
     * 显示注册页面
     * @return
     */
    @RequestMapping("/user/showRegister")
    public String showRegister() {
        return "register";
    }

    /**
     * 检查用户名、电话、邮箱是否存在
     * {param}/{type}中对应地数字代表什么在开发文档里面有写明
     * @param param
     * @param type
     * @return
     */
    @RequestMapping("/user/check/{param}/{type}")
    //@responseBody注解的作用是将controller的方法返回的对象通过适当的转换器转换为指定的格式之后，写入到response对象的body区，通常用来返回JSON数据或者是XML
    //数据，需要注意的呢，在使用此注解之后不会再走试图处理器，而是直接将数据写入到输入流中，他的效果等同于通过response对象输出指定格式的数据。
    @ResponseBody
    public EgoResult check(@PathVariable String param, @PathVariable int type) {
        TbUser tbUser = new TbUser();
        System.out.println("进来了" + type + param);
        if (type == 1) {
            tbUser.setUsername(param);
        } else if (type == 2) {
            tbUser.setPhone(param);
        } else if (type == 3) {
            tbUser.setEmail(param);
        }
        return passportService.check(tbUser);
    }

    /**
     * 显示注册页面
     * 服务端注册信息校验(服务端地信息校验一般放在控制器来做)（这个项目的信息校验我们放在服务器端来做)
     * 注意：java编程中对于对象要下意识地对对象非空进行判断
     * @return
     */
    @RequestMapping("/user/register")
    @ResponseBody
    public EgoResult register(TbUser tbUser, String pwdRepeat) {
        if (Strings.isEmpty(tbUser.getUsername()) || !tbUser.getUsername().matches("^[a-zA-Z0-9]{6,12}$")) {
            return EgoResult.error("用户名必须是6-12位，且只能是数字和字母");
        }
        if (Strings.isEmpty(tbUser.getEmail()) || !tbUser.getEmail().matches("^[a-z\\d]+(\\.[a-z\\d]+)*@([\\da-z](-[\\da-z])?)+(\\.{1,2}[a-z]+)+$")) {
            return EgoResult.error("邮箱格式不正确");
        }
        if (Strings.isEmpty(pwdRepeat) || !pwdRepeat.equals(tbUser.getPassword())) {
            return EgoResult.error("密码不一致");
        }
        if (Strings.isEmpty(tbUser.getPassword()) || !tbUser.getPassword().matches("^[a-zA-Z0-9]{6,12}$")) {
            return EgoResult.error("密码必须是6-12位，且只能是数字和字母");
        }
        if (Strings.isEmpty(tbUser.getPhone()) || !tbUser.getPhone().matches("^1\\d{10}$")) {
            return EgoResult.error("手机号不正确");
        }
        return passportService.register(tbUser);
    }

    /**
     * 登录
     * 导入spring-session-data-redis依赖和application.yml配置文件中有redis后，我们就能直接用分布式项目共享地HttpSession了
     * @param tbUser
     * @return
     */
    @RequestMapping("/user/login")
    @ResponseBody
    public EgoResult login(TbUser tbUser, HttpSession session) {
        EgoResult er = passportService.login(tbUser);
        if (er.getStatus() == 200) {
            session.setAttribute("loginUser", er.getData());
            //客户端也不需要，且用户密码等敏感信息都没处理,不要返回。
            er.setData(null);
        }
        return er;
    }

    @RequestMapping("/user/token/{token}")
    @ResponseBody
    // 异步请求携带cookie时,需要设置allowCredentials=true表示允许接收cookie数据
    @CrossOrigin(allowCredentials = "true")
    public EgoResult token(HttpSession session) {
        Object obj = session.getAttribute("loginUser");
        if (obj != null) {
            TbUser tbUser = (TbUser) obj;
            tbUser.setPassword("");
            return EgoResult.ok(tbUser);
        }
        return EgoResult.error("获取用户信息失败");
    }

    /**
     * 退出登录
     * @param session
     * @return
     */
    @RequestMapping("/user/logout/{token}")
    @ResponseBody
    @CrossOrigin(allowCredentials = "true")
    public EgoResult logout(HttpSession session){
        session.invalidate();
        return EgoResult.ok();
    }
}
