package com.ego.passport.service.impl;

import com.ego.commons.pojo.CartPojo;
import com.ego.commons.pojo.EgoResult;
import com.ego.commons.utils.CookieUtils;
import com.ego.commons.utils.IDUtils;
import com.ego.commons.utils.JsonUtils;
import com.ego.commons.utils.ServletUtil;
import com.ego.dubbo.service.TbUserDubboService;
import com.ego.passport.service.PassportService;
import com.ego.pojo.TbUser;
import org.apache.dubbo.config.annotation.Reference;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Wang PeiZhou
 * Date: 2020-06-01
 */

/**
 * 注意：
 * 基于高内聚地思想，以后所有要获取登录信息地操作都只能在ego_passport项目中做
 * 如果ego_passport项目部署在了多个服务器上，那我们得用分布式session解决方案来解决session共享问题
 */
@Service
public class PassportServiceImpl implements PassportService {
    @Reference
    private TbUserDubboService tbUserDubboService;
    // tempcart
    @Value("${ego.cart.tempcart}")
    private String tempCartCookeName;
    // cart:
    @Value("${ego.cart.rediskey}")
    private String cartRedisKey;
    @Autowired
    private RedisTemplate<String,Object> redisTemplate;

    @Override
    public EgoResult check(TbUser tbUser) {
        TbUser user = tbUserDubboService.selectByUser(tbUser);

        if (user == null) {
            System.out.println("返回ok");
            return EgoResult.ok();
        }
        System.out.println("返回error");
        return EgoResult.error("已经存在");
    }

    @Override
    public EgoResult register(TbUser tbUser) {
        tbUser.setId(IDUtils.genItemId());
        Date date = new Date();
        tbUser.setCreated(date);
        tbUser.setUpdated(date);
        //密码进行加密,在当前项目中直接使用Spring Framework的工具类DigestUtils
        String pwd = DigestUtils.md5DigestAsHex(tbUser.getPassword().getBytes());
        tbUser.setPassword(pwd);
        int index = tbUserDubboService.insert(tbUser);
        if (index == 1) {
            return EgoResult.ok();
        }
        return EgoResult.error("注册失败");
    }

    @Override
    public EgoResult login(TbUser tbUser) {
        // 需要对密码进行加密
        String pwdMd = DigestUtils.md5DigestAsHex(tbUser.getPassword().getBytes());
        tbUser.setPassword(pwdMd);
        TbUser user = tbUserDubboService.selectByUsernamePwd(tbUser);
        if(user!=null){

            /**
             *  我们把临时购物车和用户购物车的合并操作放在了ego_passport项目中的login方法中来实现，而没有放在购物车项目ego_cart中，具体原因如下：
             *  1.我们实在登录的时候才合并购物车的
             *  2.如果我们把这段代码写在购物车项目ego_cart中，我们在ego_passport项目中的login方法中得写一个HttpClient，但HttpClient发送请求
             *      的信息中是不携带cookie的，我们只能硬性在login方法中把cookie取出来然后自己拼接出一个cookie内容在使用HttpClient，这样特别麻烦
             *  思路：1. 把临时购物车数据添加到用户购物车中 ；2. 把cookie数据删除
             */
            String cookieValue = CookieUtils.getCookieValueBase64(ServletUtil.getRequest(), tempCartCookeName);
            if(Strings.isNotEmpty(cookieValue)){
                Map<Long, CartPojo> tempCart = JsonUtils.jsonToMap(cookieValue, Long.class, CartPojo.class);
                // 把临时购物车数据放入到redis中。
                String key =cartRedisKey+user.getId();
                List<CartPojo> list = (List<CartPojo>) redisTemplate.opsForValue().get(key);
                for(Long id : tempCart.keySet()){
                    boolean isExists = false;
                    // 如果临时购物车中某个商品和用户购物车中商品有重复，只修改数量
                    for(CartPojo cp : list){
                        if(cp.getId().equals(id)){
                            cp.setNum(cp.getNum()+tempCart.get(id).getNum());
                            isExists = true;
                            break;
                        }
                    }
                    if(!isExists){
                        list.add(tempCart.get(id));
                    }
                }
                // 合并成功
                redisTemplate.opsForValue().set(key,list);
                // 删除临时购物车（注意，javaEE没有提供删除cookie的API，我们这里是一种妙用，在CookieUtils工具类中设置cookie的value为"",有效时间为-1）
                CookieUtils.deleteCookie(ServletUtil.getRequest(),ServletUtil.getResponse(),tempCartCookeName);
            }

            // 一定要把user放在Egoresult中，控制器需要把用户信息放到作用域
            return EgoResult.ok(user);
        }
        return EgoResult.error("用户名或密码不正确");
    }
}
