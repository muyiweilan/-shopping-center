package com.ego.trade.service.impl;

import com.ego.commons.pojo.DeleteCartPojo;
import com.ego.commons.pojo.OrderPojo;
import com.ego.commons.pojo.RabbitmqMailPojo;
import com.ego.commons.utils.ServletUtil;
import com.ego.pojo.TbOrderItem;
import com.ego.pojo.TbUser;
import com.ego.sender.Send;
import com.ego.trade.service.TradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Wang PeiZhou
 * Date: 2020-06-04
 */
@Service
public class TradeServiceImpl implements TradeService {
    @Autowired
    private Send send;
    @Value("${ego.rabbitmq.order.createorder}")
    private String createOrder;
    @Value("${ego.rabbitmq.order.deletecart}")
    private String deleteCart;
    @Value("${ego.rabbitmq.mail}")
    private String mail;

    @Override
    public Map<String, Object> createOrder(OrderPojo orderPojo) {
        //有返回值了，此时变成了同步消息了，在这里我用到rabbitmq的排队功能，而不是异步功能，所以该等还得等，等待时间无法缩短
        String result = (String) send.sendAndReceive(createOrder, orderPojo);
        System.out.println(result!=null?"订单创建成功":"订单创建失败");

        //删除用户购物车中商品
        DeleteCartPojo dcp = new DeleteCartPojo();
        TbUser tbUser = (TbUser) ServletUtil.getRequest().getSession().getAttribute("loginUser");
        dcp.setUserId(tbUser.getId());
        List<TbOrderItem> list = orderPojo.getOrderItems();
        //由于TbOrderItem中的信息是封装在对象里面的，我们循环遍历将其转化为字符串
        StringBuffer sb = new StringBuffer();
        for(int i = 0;i < list.size();i++){
            sb.append(list.get(i).getItemId());
            if(i< list.size()-1){
                sb.append(",");
            }
        }
        dcp.setItemIds(sb.toString());
        send.send(deleteCart,dcp);
        //发送邮件是耗时操作
        //发送邮件
        RabbitmqMailPojo rmp = new RabbitmqMailPojo();
        rmp.setOrderId(result);
        rmp.setEmail(tbUser.getEmail());
        send.send(mail,rmp);
        //下面要把将要返回页面的信息封装到Map中，之所以用Map是因为Map返回到控制器中可以直接将这个Map对象直接放到作用域中，其key和value分别对应作用域中的key和value
        Map<String,Object> resultMap = new HashMap<>();
        if (result != null) {
            resultMap.put("orderId",result);
            resultMap.put("payment",orderPojo.getPayment());
            //返回页面预计的到货时间实现逻辑：当天11点之前下订单，预计当天下午送到；11点到23点下单，预计第二天上午送到；23点之后第二天下午送到。
            //获取当前时间
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            if (hour < 11) {
                //注意：由于返回页面只显示上午还是下午，没有具体小时数，所以这里给出的小时数也就是意思以下这个时间在上午还是在下午
                calendar.set(Calendar.HOUR_OF_DAY,17);
            }else if(hour >= 11 && hour < 23){
                calendar.add(Calendar.DATE,1);
                calendar.set(Calendar.HOUR_OF_DAY,9);
            }else{
                calendar.add(Calendar.DATE,1);
                calendar.set(Calendar.HOUR_OF_DAY,17);
            }
            resultMap.put("date",calendar.getTime());
            return resultMap;
        }

        return null;
    }
}
