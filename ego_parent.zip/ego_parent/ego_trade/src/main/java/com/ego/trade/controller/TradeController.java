package com.ego.trade.controller;

import com.ego.commons.pojo.OrderPojo;
import com.ego.trade.service.TradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;

/**
 * Wang PeiZhou
 * Date: 2020-06-04
 */
@Controller
public class TradeController {
    @Autowired
    private TradeService tradeService;

    @RequestMapping("/order/create.html")
    public String createOrder(OrderPojo orderPojo, Model model){
        Map<String, Object> result = tradeService.createOrder(orderPojo);
        if (result != null) {
            //这里传入的是一个Map，所以我们得用addAllAttributes()，而不能用addAttribute()
            model.addAllAttributes(result);
            return "success";
        }
        model.addAttribute("message","订单创建失败");
        return "error/exception";
    }
}
