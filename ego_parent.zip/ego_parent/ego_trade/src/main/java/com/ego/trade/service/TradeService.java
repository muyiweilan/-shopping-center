package com.ego.trade.service;

import com.ego.commons.pojo.OrderPojo;

import java.util.Map;

/**
 * Wang PeiZhou
 * Date: 2020-06-04
 */
public interface TradeService {
    /**
     * 创建订单
     */
    Map<String,Object> createOrder(OrderPojo orderPojo);
}
