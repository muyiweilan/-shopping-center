package com.ego.mail;

import freemarker.template.Template;
import freemarker.template.TemplateException;
import javafx.scene.layout.BorderImage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Wang PeiZhou
 * Date: 2020-06-05
 */
@Component
public class MyMailSender {
    @Value("${spring.mail.username}")
    private String from;
    @Autowired
    private JavaMailSender javaMailSender;
    @Autowired
    private FreeMarkerConfigurer freeMarkerConfigurer;

    public void send(String to,String orderId){
        try {
            //整个邮件对象（MimeMessage类型的对象包含了发送邮件的所有功能
            MimeMessage message = javaMailSender.createMimeMessage();
            //但是那个API使用起来不方便，通常借助工具类MimeMessageHelper来辅助我们写邮件，参数一：MimeMessage类型的对象；参数二：是否有附加功能；参数三：字符编码
            MimeMessageHelper helper = new MimeMessageHelper(message,false,"UTF-8");
            helper.setFrom(from);
            helper.setTo(to);
            helper.setSubject("易购商城下单成功确认邮件");
            /**
             * 下面我们使用freemarker来完成内容的填写
             */
            //首先读取***.ftl文件
            Template template = freeMarkerConfigurer.getConfiguration().getTemplate("mailContent.ftl");
            //创建一个Map来对***.ftl文件进行占位内容的填充
            Map<String,Object> map = new HashMap<>();
            map.put("orderId", orderId);
            //利用工具类FreeMarkerTemplateUtils将填充信息Map填充到读取到的***.ftl文件中
            String page = FreeMarkerTemplateUtils.processTemplateIntoString(template, map);
            //！！！注意：如果内容包含html，第二个参数一定要设置为true，表示解析html，否则把htmL当作字符串处理。
            helper.setText(page,true);
            javaMailSender.send(message);
        } catch (MessagingException | IOException | TemplateException e) {
            e.printStackTrace();
        }

    }
}
