package com.ego.portal.service;

/**
 * Wang PeiZhou
 * Date: 2020-05-21
 */
public interface PortalService {
    /**
     * 显示大广告,实现类中用@Cacheable相同不更新的redis缓存
     * @return
     */
    String showBigAd();

    /**
     * 显示大广告,实现类中用@CachePut键相同也要更新（恒更新）的redis缓存
     * @return
     */
    String showBigAd2();
}
